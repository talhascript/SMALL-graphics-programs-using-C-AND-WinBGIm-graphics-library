#include <graphics.h>
#include<cmath>

#include "circle.hpp"

Circle::Circle(int _x, int _y, int _radius): radius(_radius) {}
