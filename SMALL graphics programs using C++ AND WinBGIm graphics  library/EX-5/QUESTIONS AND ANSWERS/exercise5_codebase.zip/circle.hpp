#ifndef CIRCLE_H
#define CIRCLE_H

class Circle
{
protected:
    int radius;

public:
    Circle(int _x = 0, int _y = 0, int _radius = 0);
};

#endif