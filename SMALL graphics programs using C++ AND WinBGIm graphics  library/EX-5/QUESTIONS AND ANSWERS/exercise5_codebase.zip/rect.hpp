#ifndef RECT_H
#define RECT_H

class Rect
{
protected:
    int width, height;

public:
    Rect(int _x = 0, int _y = 0, int _width = 0, int _height=0);
   
};

#endif